/**
 * Copyright (c) 2024 Raspberry Pi Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

// Support old header for compatibility (and if included, support old variable name)
#include "hardware/structs/io_bank0.h"
#define iobank0_hw io_bank0_hw