/**
 * \defgroup boot_stage2 boot_stage2
 * \brief Second stage boot loaders responsible for setting up external flash
 */
